﻿Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("TaskbarX")>
<Assembly: AssemblyDescription("Center taskbar icons.")>
<Assembly: AssemblyCompany("Chris Andriessen")>
<Assembly: AssemblyProduct("TaskbarX")>
<Assembly: AssemblyCopyright("Copyright © Chris Andriessen 2021")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("0d2b7f17-f491-4d2d-ae31-74b70cd2def2")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.7.6.0")>
<Assembly: AssemblyFileVersion("1.7.6.0")>